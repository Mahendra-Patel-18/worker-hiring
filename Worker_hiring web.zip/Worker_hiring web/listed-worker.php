<?php
session_start();
include "atclass.php";

if (isset($_POST['submit'])) {
    $worker_name = $_POST['worker_name'];
    $worker_email = $_POST['worker_email'];
    $worker_gender = $_POST['gender'];
    $worker_job_type = $_POST['worker_categoryID'];
    $worker_phone = $_POST['worker_mobileNO'];
    $worker_aadhar = $_POST['worker_aadhar'];
    $worker_areaID = $_POST['worker_areaID'];
    $worker_address = $_POST['worker_address'];
    $worker_hourcharge = $_POST['worker_hourcharge'];
    $worker_perhourcharge = $_POST['worker_perhourcharge'];
    $visit_charge = $_POST['visit_charge'];

    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["txt1"]["name"]);
    move_uploaded_file($_FILES["txt1"]["tmp_name"], $target_dir);

    $insert_query = "INSERT INTO worker_listed (worker_name, worker_email, worker_gender, worker_job_type, worker_phone, worker_aadhar, worker_areaID, worker_image, worker_address, worker_perhourcharge) VALUES ('$worker_name', '$worker_email', '$worker_gender', '$worker_job_type', '$worker_phone', '$worker_aadhar', '$worker_areaID', '$target_file', '$worker_address', '$worker_perhourcharge')";
    
    if(mysqli_query($connection, $insert_query)) {
        echo "<script>alert('Congratulations, You've been hired!'); </script>";
        exit;
    } else {
        echo "Error: " . $insert_query . "<br>" . mysqli_error($connection);
    }
}
?>

<?php
include "header.php";
?>

<div class="page-title">
  <div class="container">
    <div class="page-caption">
      <h2>Worker's</h2>
      <p><a title="Home">Home</a> <i class="ti-angle-double-right"></i>Worker's</p>
    </div>
  </div>
</div>
<!--
<div class="text-center mrg-bot-20">
  <?php //if (isset($_SESSION['user_id'])) { ?>
    <h3> Hi <?php //echo $_SESSION['user_name']; ?>! Are You Searching For Job? Join With Us And Make Life Easier.</h3> 
    <a href="#" data-toggle="modal" data-target="#apply-job" class="btn-job theme-btn job-apply">Join Now</a>
  <?php //} else { ?>
    <h3>Please Log-In to join as a Worker</h3>
    <a href="login.php" class="btn-job theme-btn">Log In</a> <!-- Added btn-sm class -->
  <?php //} ?>
</div> -->
<!--

<div class="modal fade" id="apply-job" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
        <div class="text-center mrg-bot-20">
          <h4 class="mrg-0"></h4>
          <span></span>
        </div>
        <form action="" method="post" enctype="multipart/form-data">
          <div class="col-md-6 col-sm-6">
            <label>Name</label>
            <input type="text" class="form-control" placeholder="Name" name="worker_name" required>
          </div>
          <div class="col-md-6 col-sm-6">
            <label>Email</label>
            <input type="email" class="form-control" placeholder="Email" name="worker_email" required>
          </div>
          <div class="col-md-6 col-sm-6">
            <label>Gender</label>
            <div>
              <label>
                <input type="radio" name="gender" value="Male" required>
                Male
              </label>
              <label>
                <input type="radio" name="gender" value="Female" required>
                Female
              </label>
            </div>
          </div>
          <div class="col-md-6 col-sm-6">
            <label>Job Type</label>
            <input type="text" class="form-control" placeholder="Job Type" name="worker_categoryID" required>
          </div>
          <div class="col-md-6 col-sm-6">
            <label>Phone</label>
            <input type="text" class="form-control" placeholder="Phone" name="worker_mobileNO" required>
          </div>
          <div class="col-md-6 col-sm-6">
            <label>Aadhar</label>
            <input type="text" class="form-control" placeholder="Aadhar Number" name="worker_aadhar" required>
          </div>
          <div class="col-md-6 col-sm-6">
            <label>Area ID</label>
            <input type="text" class="form-control" placeholder="Area ID" name="worker_areaID" required>
          </div>
          <div class="col-md-6 col-sm-6">
            <label>Image</label>
            <input type="file" class="form-control" id="exampleInputFile" name="txt1" placeholder="Upload Your Image" required>
          </div>
          <div class="col-md-12">
            <label>Address</label>
            <textarea class="form-control height-120" placeholder="Address" name="worker_address" required></textarea>
          </div>
          <div class="col-md-12 text-center">
            <button type="submit" name="submit" class="btn theme-btn btn-m full-width">Confirm</button>
          </div>
          <div class="clearfix"></div>
        </form>
      </div>
    </div>
  </div>
</div>
  -->


<section class="padd-top-20 padd-bot-30">
  <div class="container"> 
    <div class="row"> 
    <div class="col-md-12">
          <div class="widget-boxed-body">
            <div class="search_widget_job">

            </div>
          </div>
        </div>
      </div>
      
      <!-- Start Job List -->
      <div class="col-md-12 col-sm-6">
        <div class="row mrg-bot-20">
          <div class="col-md-4 col-sm-12 col-xs-12 browse_job_tlt">
            <h2 class="job_vacancie"> Worker's</h2>

          </div>
          <div class="col-md-7 col-sm-8 col-xs-8">
            <div class="fl-right short_by_filter_list">
              <div class="search-wide short_by_til">
                <h5>Short By</h5>
              </div>
              <div class="search-wide full">
                <select class="wide form-control">
                  <option value="1">Most Recent</option>
                  <option value="2">Most Viewed</option>
                  <option value="3">Most Search</option>
                </select>
              </div>
              <div class="search-wide full">
                <select class="wide form-control">
                  <option>10 Per Page</option>
                  <option value="1">20 Per Page</option>
                  <option value="2">30 Per Page</option>
                </select>
              </div>
            </div>
          </div>
        </div>



        <?php
        if (isset($_GET['pid']) ) {
          $cid = $_GET['pid'];
          
          $q = mysqli_query($connection, "select * from worker where worker_categoryID='{$cid}'");
        
        
        }
       
         else {
          $q = mysqli_query($connection, "select * from worker");
        }
        $count = mysqli_num_rows($q);
        //echo "<h6>$count Records Found<br/></h6>";
        while ($data = mysqli_fetch_array($q)) {
        ?>
          <div class="col-md-3 top_brand_left">
            <div class="hover14 column">
              <div class="agile_top_brand_left_grid">
                <div class="agile_top_brand_left_grid1">
                  <figure>
                    <div class="snipcart-item block">
                      <div class="snipcart-thumb">
                        <a href="listed-worker-detail.php?pid=<?php echo $data['worker_id']; ?>"><img style="width: 200px;height: 150px;" src="admin/<?php echo $data['worker_image']; ?>"></a>
                        <a href="listed-worker-detail.php?pid=<?php echo $data['worker_id']; ?>">
                          <h4><?php echo $data['worker_name']; ?></h4>
                        </a>
                      </div>
                    </div>
                  </figure>
                </div>
              </div>
            </div>
          </div>
        <?php
        }
        ?>
        <div class="clearfix"></div>
      </div>
    </div>
  </div>
</section>

<?php
include "footer.php";
?>
