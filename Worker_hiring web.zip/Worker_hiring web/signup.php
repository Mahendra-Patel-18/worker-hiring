<?php
session_start();

include "atclass.php";
if ($_POST) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $gender = isset($_POST['gender']) ? $_POST['gender'] : "";
    $address = $_POST['address'];
    $password = $_POST['password'];
    $mobileNo = $_POST['mobileNo'];

    if (empty($name) || empty($email) || empty($gender) || empty($address) || empty($password) || empty($mobileNo)) {
        echo "<script>alert('Please fill in all fields');</script>";
    } else {
        $checkEmailQuery = mysqli_query($connection, "SELECT * FROM user WHERE user_email = '$email'");
        if (mysqli_num_rows($checkEmailQuery) > 0) {
            echo "<script>alert('Email already registered');</script>";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $insertQuery = mysqli_query($connection, "INSERT INTO user (user_name, user_email, user_gender, user_address, user_password, user_mobileNo) VALUES ('$name', '$email', '$gender', '$address', '$hashedPassword', '$mobileNo')");

            if ($insertQuery) {
                echo "<script>alert('Registration successful');</script>";
                header("location:login.php");
            } else {
                echo "<script>alert('Registration failed');</script>";
            }
        }
    }
}
?>

<?php
include "header.php";
?>

<div class="page-title">
    <div class="container">
        <div class="page-caption">
            <h2>Welcome ! Create an Account</h2>
            <p>Register Below</p>
        </div>
    </div>
</div>

<section class="padd-top-10 padd-bot-10">
    <div class="container">
        <div class="log-box">
            <form class="log-form" method="post" action="signup.php">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="Name" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email" placeholder="Email" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Gender</label>
                            <div>
                                <label>
                                    <input type="radio" name="gender" value="Male" required>
                                    Male
                                </label>
                                <label>
                                    <input type="radio" name="gender" value="Female" required>
                                    Female
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="address">Address</label>
                            <input type="text" class="form-control" name="address" id="address" placeholder="Address" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" name="password" id="password" placeholder="********" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="text" class="form-control" name="mobileNo" placeholder="Phone Number" required>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group text-center mrg-top-10">
                            <button type="submit" class="btn theme-btn btn-m full-width">Sign Up</button>
                        </div>
                        <div class="form-group text-center">
                            <p><b>Already have an account? <a class="" href="login.php">Login Here</b></a></p>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </form>
        </div>
    </div>
</section>



<?php
include "footer.php";
?>

<div><a href="#" class="scrollup">Scroll</a></div>

<!-- Jquery js-->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootsnav.js"></script>
<script src="assets/js/viewportchecker.js"></script>
<script src="assets/js/slick.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap-wysihtml5.js"></script>
<script src="assets/plugins/aos-master/aos.js"></script>
<script src="assets/plugins/nice-select/js/jquery.nice-select.min.js"></script>
<script src="assets/js/custom.js"></script>
<script>
    $(window).load(function() {
        $(".page_preloader").fadeOut("fast");;
    });
    AOS.init();
</script>
</body>

</html>