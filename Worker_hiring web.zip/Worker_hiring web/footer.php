

<div class="absolute">
    <footer class="footer">
        <div class="row">
            <div class="col-md-12">
                <div class="copyright text-center">
                    <p>@ 2024 All Rights Reserved.</p>		  
                </div>
            </div>
        </div>
    </footer>
</div>
