<?php
include "header1.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>

<div class="col-md-12 text-center">
    <br><br><br><br>
    <h3>Welcome to WorkerHiring Platform - Your Gateway to Seamless Job Connections!</h3>
    <p>Our Mission At WorkerHiring,</p>
    <p>our mission is to revolutionize the job market by providing a dedicated platform</p> 
    <p>that effortlessly connects skilled workers with job opportunities based on hourly rates.</p> 
    <p>We strive to create a user-friendly environment where workers can find suitable employment,</p> 
    <p>and users can efficiently book workers for specific tasks.</p>
    <br>

    <h4>Have questions or suggestions? We value your feedback!</h4>
    <b>Email: workerhiring@gmail.com</b><br>
    <b>Phone: 8114418956</b><br>
    <b>Address: B-504B, Shapath IV, Opp. Karnavati Club, S.G. Highway, Prahlad Nagar, Ahmedabad, Gujarat 380015, India</b>
    <p>Join WorkerHiring Platform today and experience a new era of efficient job connections!</p>
</div>



</body>
</html>

<?php
include "footer.php";
?>
