<?php
session_start();

include "atclass.php";

if(isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    
    $msg = "Name: $name <br>";
    $msg .= "Email: $email <br>";
    $msg .= "Subject: $subject <br>";
    $msg .= "Message: $message <br>";

    require './vendor/autoload.php';

    $mail = new PHPMailer\PHPMailer\PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'ytpt180@gmail.com'; 
        $mail->Password   = 'kcutmfqldedjmieh'; 
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        $mail->setFrom($email, $name);
        $mail->addAddress('mp1882708@gmail.com', 'Admin'); 
        $mail->addAddress('mayurpatel6250@gmail.com', 'Admin');
        $mail->addAddress('jaydevpatel2004@gmail.com', 'Admin');

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'Contact Us';
        $mail->Body    = $msg;

        // Send email
        $mail->send();
        echo "<script>alert('Message sent successfully.');</script>";
    } catch (Exception $e) {
        echo "<script>alert('Message could not be sent. Mailer Error: {$mail->ErrorInfo}');</script>";
    }
}