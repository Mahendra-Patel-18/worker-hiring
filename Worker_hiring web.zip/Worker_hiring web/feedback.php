<?php
session_start();
include "atclass.php"; 
include "header.php"; 

if (!isset($_SESSION['user_id'])) {
    // header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $feedback_rating = $_POST['feedback_rating'];
    $user_id = $_SESSION['user_id'];
  
    $feedback_rating = mysqli_real_escape_string($connection, $feedback_rating);
    $insert_query = "INSERT INTO feedback (feedback_rating, user_id, worker_id, feedback_date) 
    VALUES ('$feedback_rating', '$user_id', '$worker_id', CURDATE())";

    $result = mysqli_query($connection, $insert_query);
  
    if ($result) {
      echo "<script>alert('Thank You ! We value our feedback.');window.location='book-view.php';</script>";
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Feedback</title>
<style>
    .star-rating {
        direction: rtl;
        display: flex; /* Changed from inline-flex to flex */
        font-size: 30px;
        justify-content: center; /* Ensure stars are centered */
        margin-bottom: 1rem; /* Optional: Adds some space below the star rating */
    }
    .star-rating input[type="radio"] {
        display: none;
    }
    .star-rating label {
        color: #bbb;
        cursor: pointer;
        padding: 0 5px;
    }
    .star-rating label:hover,
    .star-rating label:hover ~ label,
    .star-rating input[type="radio"]:checked ~ label {
        color: orange;
    }
    .form-container {
        display: flex;
        justify-content: center; /* Center form container horizontally */
    }
    .form-inner {
        width: 100%; /* Use 100% of the form container's width */
        display: flex; /* Use flexbox to allow inner items to be centered */
        flex-direction: column; /* Stack form elements vertically */
        align-items: center; /* Center form elements horizontally */
    }
    .text-center {
        width: 100%; /* Ensure full width for center alignment */
        text-align: center; /* Center the text/buttons */
    }
</style>
</head>
<body>

<div class="page-title">
  <div class="container">
    <div class="page-caption">
      <h2>Feedback</h2>
      <p><a title="Home" href="index.php">Home</a> <i class="ti-angle-double-right"></i>Feedback</p>
    </div>
  </div>
</div>
<section class="padd-top-20 padd-bot-20">

<div class="container">
    <div class="row">
        <div class="col-md-12 form-container">
            <div class="form-inner">
                <h5>Every feedback you provide is a stepping stone towards perfection.</h5><br>
                
                <form id="feedbackForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="star-rating">
                        <input id="star5" type="radio" name="feedback_rating" value="5"><label for="star5">&#9733;</label>
                        <input id="star4" type="radio" name="feedback_rating" value="4"><label for="star4">&#9733;</label>
                        <input id="star3" type="radio" name="feedback_rating" value="3"><label for="star3">&#9733;</label>
                        <input id="star2" type="radio" name="feedback_rating" value="2"><label for="star2">&#9733;</label>
                        <input id="star1" type="radio" name="feedback_rating" value="1"><label for="star1">&#9733;</label>
                    </div>
                    <br>
                    <div class="text-center"> <!-- Center buttons -->
                        <button type="submit" class="btn theme-btn btn-m">Submit</button>
                        <button type="button" class="btn theme-btn btn-m" onclick="cancelFeedback()">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function cancelFeedback() {
        window.location = "book-view.php";
    }
</script>

</body>
</html>
