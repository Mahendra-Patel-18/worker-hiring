<?php
session_start();
include "atclass.php";
//Login Check
if (!isset($_SESSION['uid'])) {
   //header("location:login1.php");
}
if($_POST)
{

    $opass = $_POST['opass'];
    $npass = $_POST['npass'];
    $cpass = $_POST['cpass'];
    $wid = $_SESSION['worker_id'];
    $oldpassq  = mysqli_query($connection,"select * from worker where worker_id='{$wid}'");
    $oldpassdb = mysqli_fetch_array($oldpassq);
    if($oldpassdb['worker_password']==$opass)
    {
        if($npass==$cpass)
        {
            if($opass==$npass)
            {
                echo "<script>alert('Old Password and New Password Must be Different')</script>";

            }else{
                $wq = mysqli_query($connection,"update worker set worker_password = '{$npass}' where worker_id='{$wid}'");
                echo "<script>alert('Password Changed')</script>";
            }
        }else{
            echo "<script>alert('New and Confirm Password Not Match');</script>";
        }
    }else{
        echo "<script>alert('Old Password Not Match');</script>";
    }
}
?>
<!--
<html>

<body>
    <form method="post">
        Old Password :<input type="text" name="opass" />
        New Password :<input type="text" name="npass" />
        Confirm Password :<input type="text" name="cpass" />

        <input type="submit" />
    </form>
</body>

</html>
-->

<?php
include "header1.php";
?>

  <div class="page-title">
    <div class="container">
      <div class="page-caption">
        <h2>Welcome</h2>
        <p>Change Password below</p>
      </div>
    </div>
  </div>
 
  <section class="padd-top-10 padd-bot-10">
    <div class="container">
        <div class="log-box">
            <form class="log-form" method="post" action="change-password.php">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="old password">Old Password</label>
                            <input type="text" class="form-control" name="opass" id="opass" placeholder="Old Password" required>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="New Password">New Password</label>
                            <input type="text" class="form-control" name="npass" id="npass" placeholder="New Password" required>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="Confirm Password">Confirm Password</label>
                            <input type="text" class="form-control" name="cpass" id="cpass" placeholder="Confirm Password" required>
                        </div>
                    </div>

                   
                    <div class="col-md-12">
                        <div class="form-group text-center mrg-top-10">
                        <button type="submit" class="btn theme-btn full-width btn-m">Submit</button>
                    </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </form>
        </div>
    </div>
</section>

  

<?php
include "footer.php";
?>

  <div><a href="#" class="scrollup">Scroll</a></div>

  <!-- Jquery js-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/plugins/bootstrap/js/bootsnav.js"></script>
  <script src="assets/js/viewportchecker.js"></script>
  <script src="assets/js/slick.js"></script>
  <script src="assets/plugins/bootstrap/js/bootstrap-wysihtml5.js"></script>
  <script src="assets/plugins/aos-master/aos.js"></script>
  <script src="assets/plugins/nice-select/js/jquery.nice-select.min.js"></script>
  <script src="assets/js/custom.js"></script>
  <script>
    $(window).load(function () {
      $(".page_preloader").fadeOut("fast");;
    });
    AOS.init();
  </script>
</body>

</html>