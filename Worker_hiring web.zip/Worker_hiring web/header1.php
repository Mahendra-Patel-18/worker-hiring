<?php
include "atclass.php";
?>

<!DOCTYPE html>
<html class="" lang="zxx">

<head>
  <meta name="author" content="">
  <meta name="description" content="">
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WorkerHiring : WorkerPerHourBooking</title>

  <!-- Favicon Icon -->
  <link rel="shortcut icon" href="assets/img/favicon.jpeg" />

  <!-- CSS -->
  <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap-select.min.css">
  <link href="assets/plugins/icons/css/icons.css" rel="stylesheet">
  <link href="assets/plugins/animate/animate.css" rel="stylesheet">
  <link href="assets/plugins/bootstrap/css/bootsnav.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/plugins/nice-select/css/nice-select.css">
  <link href="assets/plugins/aos-master/aos.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/responsive.css" rel="stylesheet">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700&amp;display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600&amp;display=swap" rel="stylesheet">
</head>

<body class="utf_skin_area">
  <div class="page_preloader"></div>
  <!-- ======================= Start Navigation ===================== -->
  <nav class="navbar navbar-default navbar-mobile navbar-fixed white no-background bootsnav">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu"> <i class="fa fa-bars"></i> </button>
        <a class="navbar-brand"> <img src="assets/img/workerhire1.png" class="logo logo-display" alt=""> <img src="assets/img/workerhire1.png" class="logo logo-scrolled" alt=""> </a>
      </div>
      <div class="collapse navbar-collapse" id="navbar-menu">
        <ul class="nav navbar-nav navbar-left" data-in="fadeInDown" data-out="fadeOutUp">
          <li class=""> <a href="index1.php" class="dropdown-toggle" data-toggle="dropdown" style="color: black;"><b>Home</b></a>
          <li class=""> <a href="listed-worker1.php" class="dropdown-toggle" data-toggle="dropdown" style="color: black;"><b>Worker's</b></a>
           <!-- <ul class="dropdown-menu">
              <?php
              //$workerq = mysqli_query($connection, "select * from worker");
              //while ($cdata = mysqli_fetch_array($workerq)) {
             //   echo "<li><a href='worker.php'?workerid={$cdata['worker_id']}'><i class='fa fa-arrow-right' aria-hidden='true'></i>{$cdata['worker_name']}</a></li>";
              //}
              ?>
            </ul>
            -->
          <li class=""> <a href="about1.php" style="color: black;"><b>About</b></a> </li>
          <li class=""> <a href="contact1.php" style="color: black;"><b>Contact Us</b></a> </li>
          <?php
          if (isset($_SESSION['worker_id'])) {
          ?>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">Hi <?php echo $_SESSION['worker_name']; ?></a>
              <ul class="dropdown-menu">
                <li> <a href="change-password1.php"><i class="fa fa-suitcase"></i> Change Password</a> </li>
                <li> <a href="logout1.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
              </ul>
            </li>
          <?php
          } else {
            echo "<li><a href='login1.php' style='color: black;'><b>Login</b></a></li>";
          }
          ?>
        </ul>
      </div>
    </div>
  </nav>
  <!-- ======================= End Navigation ===================== -->







  <!-- Jquery js-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/plugins/bootstrap/js/bootsnav.js"></script>
  <script src="assets/js/viewportchecker.js"></script>
  <script src="assets/js/slick.js"></script>
  <script src="assets/plugins/bootstrap/js/wysihtml5-0.3.0.js"></script>
  <script src="assets/plugins/bootstrap/js/bootstrap-wysihtml5.js"></script>
  <script src="assets/plugins/aos-master/aos.js"></script>
  <script src="assets/plugins/nice-select/js/jquery.nice-select.min.js"></script>
  <script src="assets/js/custom.js"></script>
  <script>
    $(window).load(function() {
      $(".page_preloader").fadeOut("fast");;
    });
    AOS.init();
  </script>
</body>

</html>