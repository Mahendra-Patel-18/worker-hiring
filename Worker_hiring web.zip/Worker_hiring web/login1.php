<?php
session_start();
include "atclass.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $worker_email = $_POST['worker_email'];
  $worker_password = $_POST['worker_password'];

  $q = mysqli_query($connection, "select * from worker where worker_email ='{$worker_email}' and worker_password ='{$worker_password}'");

  $count = mysqli_num_rows($q);
  $row = mysqli_fetch_array($q);

  if ($count == 1) {
    $_SESSION['worker_name'] = $row['worker_name'];
    $_SESSION['worker_id'] = $row['worker_id'];
    header("location:index1.php");
  } else {
    echo "<script>alert('Login Failed');</script>";
  }
}

?>
<?php
include "header1.php";
?>

<div class="page-title">
  <div class="container">
    <div class="page-caption">
      <h2>Welcome Back </h2>
      <p>Login Below</p>
    </div>
  </div>
</div>

<section class="padd-top-10 padd-bot-10">
  <div class="container">
    <div class="col-md-12">
      <form class="log-form" method="post">
        <div class="row justify-content-center">
          <ul class="nav nav-tabs nav-advance theme-bg" role="tablist">
            <li class="nav-item">
              <a class="nav-link" data-toggle="tab" href="#candidate" role="tab">
                <i class="ti-user"></i> User
              </a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" data-toggle="tab" href="login.php" role="tab">
                <i class="ti-worker"></i> Worker
              </a>
            </li>
          </ul>

          <div class="tab-content">
            <div class="tab-pane fade in show active" id="candidate" role="tabpanel">
              <div class="text-center">
                <div style="width: 30%; margin: 0 auto;">
                  <input type="text" class="form-control" placeholder="Email Address" name="worker_email" id="worker_email" required>
                </div>
                <div style="width: 30%; margin: 0 auto;">
                  <input type="password" class="form-control" placeholder="Password" name="worker_password" id="worker_password" required>
                </div>
              </div>

              <div class="text-left">
              <div style="width: 30%; margin: 0 auto;">
                <label>Remember me </label>
                  <input type="checkbox" name="checkbox" checked=""/>

                <div class="forgot text-right">
                  <a href="forgotpassword1.php">forgot password?</a>
                </div>
              </div>
              <div class="form-group text-center">
                <button type="submit" class="btn theme-btn btn-m">LogIn</button>
                <p><b>Don't have an account? <a class="" href="signup1.php">Create An Account</b></a></p>
              </div>
            </div>

          </div>
          <!-- Tab panels -->
        </div>
      </form>
    </div>
  </div>
</section>


<div><a href="#" class="scrollup">Scroll</a></div>

<!-- Jquery js-->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootsnav.js"></script>
<script src="assets/js/viewportchecker.js"></script>
<script src="assets/js/slick.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap-wysihtml5.js"></script>
<script src="assets/plugins/aos-master/aos.js"></script>
<script src="assets/plugins/nice-select/js/jquery.nice-select.min.js"></script>
<script src="assets/js/custom.js"></script>
<script>
  $(window).load(function() {
    $(".page_preloader").fadeOut("fast");;
  });
  AOS.init();
</script>
</body>

</html>