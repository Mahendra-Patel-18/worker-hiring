<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
$connection = mysqli_connect("localhost","root","","itanmahendra");
if($_POST)
{
    $email = $_POST['email'];
    $q = mysqli_query($connection,"select * from user where user_email='{$email}'");
    $data = mysqli_fetch_array($q);
    $count = mysqli_num_rows($q);
    if($count==1)
    {
      $msg = "Hi {$data['user_name']},<br/> your password is ".$data['user_password']." <br/>Do not Share with anyone";
        //Load Composer's autoloader
        require 'vendor/autoload.php';
        //Create an instance; passing true enables exceptions
        $mail = new PHPMailer(true);
        try {
            //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'ytpt180@gmail.com';                      //SMTP username
            $mail->Password   =  'kcutmfqldedjmieh';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS
            //Recipients
            $mail->setFrom('ytpt180@gmail.com', 'Admin');
            $mail->addAddress($email, 'Admin');     //Add a recipient
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'Forgot Password';
            $mail->Body    = $msg;
            $mail->AltBody = $msg;
            $mail->send();
            echo "<script>alert('Password is sent on email id')</script>";
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }

    }else{
        echo "<script>alert('User Not Found')</script>";
    }

}
?>
<!--
<html>
    <body>
        <form method="post">
        Email : <input type="email" name="email"/>
        <input type="submit"/>
        </form>
    </body>
</html>
-->

<?php
include "header.php";
?>

  <div class="page-title">
    <div class="container">
      <div class="page-caption">
        <h2>Welcome</h2>
        <p>Update Password below</p>
      </div>
    </div>
  </div>
 
  <section class="padd-top-10 padd-bot-10">
    <div class="container">
            <form class="log-form" method="post">
                <div class="row">
                <div style="width: 30%; margin: 0 auto;">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email" placeholder="Enter Email ID" required>
                        </div>
                    </div>

                   
                    <div style="width: 30%; margin: 0 auto;">
                        <div class="form-group text-center mrg-top-10">
                        <button type="submit" class="btn theme-btn full-width btn-m">Submit</button>
                    </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </form>
        </div>
    </div>
</section>
  

<?php
include "footer.php";
?>

  <div><a href="#" class="scrollup">Scroll</a></div>

  <!-- Jquery js-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/plugins/bootstrap/js/bootsnav.js"></script>
  <script src="assets/js/viewportchecker.js"></script>
  <script src="assets/js/slick.js"></script>
  <script src="assets/plugins/bootstrap/js/bootstrap-wysihtml5.js"></script>
  <script src="assets/plugins/aos-master/aos.js"></script>
  <script src="assets/plugins/nice-select/js/jquery.nice-select.min.js"></script>
  <script src="assets/js/custom.js"></script>
  <script>
    $(window).load(function () {
      $(".page_preloader").fadeOut("fast");;
    });
    AOS.init();
  </script>
</body>

</html>