<?php
session_start();
include "atclass.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $payment_method = $_POST['payment_method'];
  // $payment_amount = $_POST['payment_amount']; // Removed payment_amount
  $user_id = $_SESSION['user_id'];

  $payment_method = mysqli_real_escape_string($connection, $payment_method);
  // $payment_amount = mysqli_real_escape_string($connection, $payment_amount); // Removed payment_amount

  $booking_query = "SELECT booking_id FROM booking WHERE user_id = '$user_id' ORDER BY booking_id DESC LIMIT 1";
  $booking_result = mysqli_query($connection, $booking_query);

  if ($booking_result && mysqli_num_rows($booking_result) > 0) {
    $booking_data = mysqli_fetch_assoc($booking_result);
    $booking_id = $booking_data['booking_id'];

    $insert_query = "INSERT INTO payment (payment_method, payment_date, booking_id) 
                       VALUES ('$payment_method', NOW(), '$booking_id')"; // Removed payment_amount
    $result = mysqli_query($connection, $insert_query);

    if ($result) {
      echo "<script>alert('Booking Placed!');window.location='feedback.php';</script>";
    } else {
      echo "<script>alert('Payment Failed! Please try again later.');window.location='process_payment.php';</script>";
    }
  } else {
    echo "<script>alert('No booking found for this user!');window.location='feedback.php';</script>";
  }
}
?>


<?php
include "header.php";
?>

<div class="page-title">
  <div class="container">
    <div class="page-caption">
      <h2>Payment Details</h2>
      <p><a title="Home">Home</a> <i class="ti-angle-double-right"></i>Payment Details</p>
    </div>
  </div>
</div>

<div class="container text-center">
  <section>
    <form method="post" action="">
      <div class="col-md-12">
        <div class="form-group row">
          <label class="col-sm-7 col-form-label"><h4>Payment Type</h4></label>
          <div class="col-sm-2">
            <input type="radio" id="pcash" value="Cash" name="payment_method" /> <b>Cash</b>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <!--<input type="radio" id="pupi" value="UPI"  name="payment_method" /> <b>UPI</b>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" id="pcard" value="Card" checked name="payment_method" /> <b>Credit Card / Debit Card</b>
            <div class="icon-container" style="margin-left: 190px;">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
          </div>
        </div>


        <div class="form-group row">
          <label class="col-sm-6 col-form-label">Amount</label>
          <div class="col-sm-2">
            <input type="text" class="amount" name="payment_amount" placeholder="Enter Amount" required>
          </div>
        </div>

        <div class="form-group row align-items-center cardDetails">
          <label class="col-sm-6 col-form-label">Card Number</label>
          <div class="col-sm-2">
            <input type="text" class="cardNumber" placeholder="xxxx xxxx xxxx xxxx" required>
          </div>
        </div>
        <div class="form-group row cardDetails">
          <label class="col-sm-6 col-form-label">CVV</label>
          <div class="col-sm-2">
            <input type="text" class="cvv" placeholder="xxx" required>
          </div>
        </div>
        <div class="form-group row cardDetails">
          <label class="col-sm-6 col-form-label">VALID THRU</label>
          <div class="col-sm-2">
            <input type="text" class="expirationDate" id="expirationDate" placeholder="xx/xxxx" required>
          </div>
        </div>
      </div>-->
            <button type="submit" class="theme btn-primary" name="submit" id="submit">Submit</button>
            </form>

          </section>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script>
  $(document).ready(function() {
  $('input[name="payment_method"]').change(function() {
    var selectedOption = $(this).val();
    if (selectedOption === 'Cash' || selectedOption === 'UPI') {
      $('.cardDetails').hide();
    } else {
      $('.cardDetails').show();
    }
  });

  $('.cardNumber').keyup(function() {
    var val = $(this).val().replace(/\s/g, ''); 
    val = val.replace(/(\d{4})/g, '$1 '); 
    $(this).val(val.trim()); 
    if (val.length > 19) {
      $(this).val(val.slice(0, 19)); 
    }
  });

  $('.cvv').keyup(function() {
    var val = $(this).val();
    if (val.length > 3) {
      $(this).val(val.slice(0, 3)); 
    }
  });

  });
</script>
