<?php
session_start();
include "atclass.php";
?>

<?php
include "header.php";
?>

<div class="page-title">
  <div class="container">
    <div class="page-caption">
      <h2>Categories</h2>
      <p><a title="Home">Home</a> <i class="ti-angle-double-right"></i>Categories</p>
    </div>
  </div>
</div>

<section class="padd-top-80 padd-bot-60">
  <div class="container"> 
    <div class="row"> 
    <div class="col-md-12">

      
      <!-- Start Job List -->
      <div class="col-md-12 col-sm-6">
        <div class="row mrg-bot-20">
          <div class="col-md-4 col-sm-12 col-xs-12 browse_job_tlt">
            <h2 class="job_vacancie"> Categories</h2>

          </div>
          <div class="col-md-7 col-sm-8 col-xs-8">
            <div class="fl-right short_by_filter_list">
              <div class="search-wide short_by_til">
                <h5>Short By</h5>
              </div>
              <div class="search-wide full">
                <select class="wide form-control">
                  <option value="1">Most Recent</option>
                  <option value="2">Most Viewed</option>
                  <option value="3">Most Search</option>
                </select>
              </div>
              <div class="search-wide full">
                <select class="wide form-control">
                  <option>10 Per Page</option>
                  <option value="1">20 Per Page</option>
                  <option value="2">30 Per Page</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <?php
        if (isset($_GET['category_id'])) {
          $cid = $_GET['category_id'];
          $q = mysqli_query($connection, "select * from category where category_id='{$cid}'");
        } else {
          $q = mysqli_query($connection, "select * from category");
        }
        $count = mysqli_num_rows($q);
        //echo "<h6>$count Records Found<br/></h6>";
        while ($data = mysqli_fetch_array($q)) {
        ?>
          <div class="col-md-3 top_brand_left">
            <div class="hover14 column">
              <div class="agile_top_brand_left_grid">
             
                <div class="agile_top_brand_left_grid1">
                  <figure>
                    <div class="snipcart-item block">
                      <div class="snipcart-thumb">
					            	<a href="listed-worker.php?pid=<?php echo $data['category_id']; ?>"><img style="width: 180px;height: 120px;" src="admin/<?php echo $data['category_image']; ?>"></a>
                        <a href="listed-worker.php?pid=<?php echo $data['category_id']; ?>"><h4><?php echo $data['category_name']; ?></h4></a>
                      </div>
                    </div>
                  </figure>
                </div>
              </div>
            </div>
          </div>
        <?php
        }
        ?>

        <div class="clearfix"></div>
      </div>
    </div>
  </div>
</section>


<?php
include "footer.php";
?>