<?php
session_start();
include "atclass.php";
include "header.php";

$wid = $_GET['pid'];

$q = mysqli_query($connection, "SELECT * FROM worker WHERE worker_id='{$wid}'");

$data = mysqli_fetch_array($q);

// Corrected query to fetch worker details based on worker name
$q5 = mysqli_query($connection, "SELECT * FROM worker WHERE worker_name='{$data['worker_name']}'");

$data_4 = mysqli_fetch_array($q5);

$query_2 = mysqli_query($connection, "SELECT * FROM `location` WHERE area_pincode ='{$data['worker_areaID']}' ");
// echo "SELECT * FROM `location` WHERE area_pincode ='{$data['worker_areaID']}'";
// exit();
$data_1 = mysqli_fetch_array($query_2);
?>

<div class="page-title">
  <div class="container">
    <div class="page-caption">
      <h2>Worker Details</h2>
      <p><a title="Home" href="index.php">Home</a> <i class="ti-angle-double-right"></i>Worker Details</p>
    </div>
  </div>
</div>


<section class="padd-top-80 padd-bot-60">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12"> <!-- Adjust column width as needed -->
        <div class="text-center">
          <img style="width: 200px; height: 150px;" src="admin/<?php echo $data['worker_image']; ?>" alt="Worker Image">
          <h3><?php echo $data['worker_name']; ?></h3>
          <h6>Email: <?php echo $data['worker_email']; ?></h6>
          <h6>Gender: <?php echo $data['worker_gender']; ?></h6>
          <h6>Category:
              <?php
              // Fetch category name based on category ID
              $category_id = $data['worker_categoryID'];
              $category_query = mysqli_query($connection, "SELECT category_name FROM category WHERE category_id='$category_id'");
              $category_data = mysqli_fetch_array($category_query);

              echo $category_data['category_name'];
              ?>
            </h6>
          <h6>Mobile Number: <b><?php echo $data['worker_mobileNO'];?></b></h6>
          <h6>Area ID: <b><?php echo $data_1['area_name']; ?></b></h6>         
          <h6>Price Per Hour: ₹<b><?php echo $data_4['worker_hourcharge']; ?></b></h6>

          <h6><?php
          $category_query = mysqli_query($connection, "SELECT visit_charge FROM category WHERE category_id='$category_id'");
              $category_data = mysqli_fetch_array($category_query);?>
  
          <b>Note - Minimum Charges would be <b>₹<?php echo $category_data['visit_charge']; ?> Incl all.</b></h6>
          <p><a href="#">T&C apply</a><b>


          <?php if (isset($_SESSION['user_id'])) { ?>
            <input type="hidden" name="user_id" id="user_id">
            <p><a href="#" data-toggle="modal" data-target="#apply-job" class="btn-job theme-btn job-apply">Book Now</a></p>
          <?php } else { ?>
            <h4><b>Please Log-in to book this worker.</b></h4>
          <?php } ?>

        </div>
        <?php if (!isset($_SESSION['user_id'])) { ?>
          <div class="text-center">
            <a href="login.php" class="btn-job theme-btn">LogIn</a>
          </div>
        <?php } ?>
      </div>
    </div>
  </div>
</section>

<?php
include "footer.php";
?>

<?php
if (isset($_POST['submit'])) {
  // Assuming you have the user ID stored in $_SESSION['user_id'] after successful login
  $user_id = $_SESSION['user_id'];

  $booking_address = $_POST['booking_address'];
  $booking_date = date('Y-m-d'); // Current date
  $booking_status = "Confirmed";

  // Assuming you have a database connection named $connection
  $insert_query = "INSERT INTO booking (booking_address, booking_status, booking_date, user_id) VALUES ('$booking_address', '$booking_status', '$booking_date', '$user_id')";
  mysqli_query($connection, $insert_query);

  if ($insert_query) {
    echo "<script>alert('Address Verified!');window.location='process_payment.php';</script>";
  } else {
    echo "<script>alert('Address Failed! Please try again later.');window.location='listed-worker-detail.php';</script>";
  }
}
?>

<div class="modal fade" id="apply-job" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" id="myModalLabel2">
      <div class="modal-body">
        <div class="text-center mrg-bot-20">
          <h4 class="mrg-0"></h4>
          <span></span>
        </div>
        <form method="post">
          <div class="col-md-12">
            <label>Address</label>
            <textarea class="form-control height-120" placeholder="Address" name="booking_address" required></textarea>
          </div>
          <div class="col-md-12 text-center">
            <button type="submit" name="submit" class="btn theme-btn btn-m full-width">Proceed</button>
          </div>
          <div class="clearfix"></div>
        </form>
      </div>
    </div>
  </div>
</div>
