<?php
session_start();

include "atclass.php";

if(isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    
    $msg = "Name: $name <br>";
    $msg .= "Email: $email <br>";
    $msg .= "Subject: $subject <br>";
    $msg .= "Message: $message <br>";

    require './vendor/autoload.php';

    $mail = new PHPMailer\PHPMailer\PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'ytpt180@gmail.com'; 
        $mail->Password   = 'kcutmfqldedjmieh'; 
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        $mail->setFrom($email, $name);
        $mail->addAddress('mp1882708@gmail.com', 'Admin'); 
        $mail->addAddress('mayurpatel6250@gmail.com', 'Admin');
        $mail->addAddress('jaydevpatel2004@gmail.com', 'Admin');

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'Contact Us';
        $mail->Body    = $msg;

        // Send email
        $mail->send();
        echo "<script>alert('Message sent successfully.');</script>";
    } catch (Exception $e) {
        echo "<script>alert('Message could not be sent. Mailer Error: {$mail->ErrorInfo}');</script>";
    }
}

include "header.php";
?>

<section class="padd-top-80 padd-bot-70">
    <div class="container">
        <div class="col-md-6 col-sm-6">
            <div class="row">
                <form method="post" class="mrg-bot-40">
                    <div class="col-md-6 col-sm-6">
                        <label>Name:</label>
                        <input type="text" name="name" class="form-control" placeholder="Name" required/>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <label>Email:</label>
                        <input type="email" name="email" class="form-control" placeholder="Email" required/>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <label>Subject:</label>
                        <input type="text" name="subject" class="form-control" placeholder="Subject" required/>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <label>Message:</label>
                        <textarea name="message" class="form-control height-120" placeholder="Message" required></textarea>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <button type="submit" name="submit" class="btn theme-btn">Send Message</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-6 col-sm-6">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d235014.29980906486!2d72.41458622666332!3d23.020157728126893!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e848aba5bd449%3A0x4fcedd11614f6516!2sAhmedabad%2C%20Gujarat!5e0!3m2!1sen!2sin!4v1707373583293!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
</section>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Social Icons</title>

<style>
    .social-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 25%; 
    }

    .social-icons {
        list-style-type: none;
        padding: 0;   
    }

    .social-icons li {
        display: inline-block;
        margin-right: 6px;
    }

    .social-icons li:last-child {
        margin-right: 0;
    }

    .social-icons a {
        text-decoration: none;
        color: #333;
        font-size: 24px;
    }

    .social-icons a:hover {
        color: #007bff;
    }

    .social-icons img {
        width: 50px;
        height: 50px;
        margin-bottom: 10px;
    }

    .absolute {
        position: absolute;
        bottom: -70px;
        width: 50%;
        left: 25%; 
        text-align: center; 
    }

    .fa.fa-twitter {
        font-family: sans-serif;
    }

    .fa.fa-twitter::before {
        content: "𝕏";
        color: #333;
        font-size: 1.2em;
    }
</style>
</head>
<body>

<div class="social-container"> 
    <div class="container"> 
        <div class="row">
            <div class="col-md-12 text-center">
                <h3>Let's get social</h3>
                <div class="f-social-box">
                    <ul class="social-icons">
                        <li><a href="#"><i class="fa fa-facebook facebook-cl"></i></a></li>
                        <li><a href="https://github.com/Mahendra-Patel-18/Mahendra-Patel-18/blob/main/README.md"><i class="fa fa-github github-cl"></i></a></li>
                        <li><a href="https://x.com/Mahendra_125?t=G3U_FwTLAOvaxnxUYW9u9g&s=09"><i class="fa fa-twitter twitter-cl"></i></a></li>
                        <li><a href="https://www.instagram.com/_mahendra.12_?igsh=YzllMWlkeWM1NG5r"><i class="fa fa-instagram instagram-cl"></i></a></li>
                        <li><a href="#"><i class="fa fa-whatsapp whatsapp-cl"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube youtube-cl"></i></a></li>
                        <li><a href="https://www.snapchat.com/add/mahendra.125?share_id=onmLZh3P7BE&locale=en-US"><i class="fa fa-snapchat snapchat-cl"></i></a></li>
                        <li><a href="https://www.linkedin.com/in/mahendrajay18?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app"><i class="fa fa-linkedin linkedin-cl"></i></a></li>
                    </ul>
                </div>        
            </div>  
        </div>
    </div>
</div>

</body>
</html>


<?php
include "footer.php";
?>
