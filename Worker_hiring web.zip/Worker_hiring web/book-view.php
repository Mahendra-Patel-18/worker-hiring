<?php
session_start();
include "atclass.php";

$user_id = $_SESSION['user_id'];

?>

<?php
include "header.php";
?>

<div class="page-title">
  <div class="container">
    <div class="page-caption">
      <h2>Book view</h2>
      <p><a title="Home" href="index.php">Home</a> <i class="ti-angle-double-right"></i>Book view</p>
    </div>
  </div>
</div>

<section class="padd-top-40 padd-bot-40">
  <div class="container">
    <div class="row">

      <?php
      $q_book = mysqli_query($connection, "SELECT * FROM `booking` WHERE user_id='{$user_id}'");
      $count = mysqli_num_rows($q_book);
      if ($count > 0) {
      ?>
        <table class="table" border="1" width="100%" cellspacing="">
          <thead>
            <th>Serial No.</th> <!-- Column for row numbers -->
            <th>Name</th>
            <th>Booking Date</th>
           <!--  <th>Worker Name</th>-->
           <!--  <th>Worker Type</th>-->
            <th>Booking Address</th>
           <!-- <th>Visiting Charge</th>-->
          </thead>

          <tbody>
            <?php
            $i = 1; // Initialize counter variable
            while ($data = mysqli_fetch_array($q_book)) {
              $query_worker = mysqli_query($connection, "SELECT * FROM `booking` WHERE `booking_id`='{$data['booking_id']}'");
              // echo "SELECt * FROM `booking` WHERE `booking_id`='{$data['booking_id']}'";
              // exit();
              $data_worker = mysqli_fetch_array($query_worker);

            ?>
              <tr>
                <td><?php echo $i++; ?></td>
                <td><?php echo $_SESSION['user_name']; ?></td>
                <td><?php echo $data['booking_date']; ?></td>
                <!-- <td><?php //echo $data['worker_name']; ?></td>-->
                <!-- <td><?php //echo $data['worker_type']; ?></td> -->
                <td><?php echo $data['booking_address']; ?></td>
               <!-- <td><?php //echo $data['booking_amount']; ?></td> -->
              </tr>

            <?php } ?>
          </tbody>
        </table>
      <?php } else {
      ?>

        <h3>No Record Found</h3>
      <?php
      }
      ?>

    </div>
  </div>
</section>

<?php
include "footer.php";
?>