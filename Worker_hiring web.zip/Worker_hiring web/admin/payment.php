<?php
require './atclass.php';
$msg = "";
if ($_POST) {
	$Pid = mysqli_real_escape_string($connection, $_POST['txt1']);
	$method = mysqli_real_escape_string($connection, $_POST['txt2']);
	$amount = mysqli_real_escape_string($connection, $_POST['txt3']);
	$date = mysqli_real_escape_string($connection, $_POST['txt4']);
	$Bid = mysqli_real_escape_string($connection, $_POST['txt5']);

	$query = mysqli_query($connection, "INSERT INTO payment(payment_id,payment_method,payment_amount,payment_date,booking_id) 
VALUES ('{$Pid}','{$method}','{$amount}','{$date}','{$Bid}')") or die(mysqli_error($connection));

	if ($query) {
		$msg = '<div class="alert alert-success" role="alert">
	record added
  </div>';
	}
}
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
	<div class="main-page">
		<div class="forms">
			<h2 class="title1">Payment</h2>
			<?php
			echo $msg;
			?>

			<div class=" form-grids row form-grids-right">
				<div class="widget-shadow " data-example-id="basic-forms">

					<div class="form-title">
						<h4>Payment details :</h4>
					</div>
					<div class="form-body">
						<form class="form-horizontal" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Payment Id</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt1" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Payment method</label>


								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt2" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Payment amount</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt3" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Payment_date</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt4" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Booking Id</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt5" required>
								</div>
							</div>

					</div>
					<div class="col-sm-offset-2"> <button type="submit" class="btn btn-primary">submit</button> </div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
include "footer.php";
?>