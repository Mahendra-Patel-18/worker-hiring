<?php
require './atclass.php';
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
    <div class="main-page">
        <div class="tables">
            <h2 class="title1">location_table </h2>
            <div class="panel-body widget-shadow">

                <a href="location.php">
                    <h4>location details </h4>
                </a>
                <table class="table">
                    <thead>
                        <tr>

                            <th>area id</th>
                            <th>area name</th>
                            <th>area pincode</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (isset($_GET['did'])) {
                            $did = $_GET['did'];

                            $deleteq =  mysqli_query($connection, "delete from location where area_id ='{$did}'") or die(mysqli_error($connection));
                            if ($deleteq) {
                                echo "<script>alert('record_deleted')</script>";
                            }
                        }
                        $selectq = mysqli_query($connection, "select * from location") or die(mysqli_error($connection));
                        $count = mysqli_num_rows($selectq);


                        echo $count . "record_found";
                        while ($locationrow = mysqli_fetch_array($selectq)) {
                            echo "<tr>";
                            echo "<td>{$locationrow['area_id']}</td>";
                            echo "<td>{$locationrow['area_name']}</td>";
                            echo "<td>{$locationrow['area_pincode']}</td>";
                            echo "<td><a href='location.php?eid={$locationrow['area_id']}'>EDIT</a> |<a href='disply-location.php?did={$locationrow['area_id']}'> DELETE</a> <td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

<?php
include "footer.php";
?>