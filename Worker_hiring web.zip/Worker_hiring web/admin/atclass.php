<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "itanmahendra";

$connection = mysqli_connect($host,$user,$password,$database);
?>