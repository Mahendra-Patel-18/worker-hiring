<?php
include "atclass.php";
?>

<html>
    <body>
    <center><img width="200" src="./images/workerhire.jpeg"></center>
        <hr/>
        <center> <h4>Feedback Report</h4> </center>
        <?php
        echo "Date: " . date('d-m-y');
        ?>
        <form method="get">

            <?php
            $sql = mysqli_query($connection, "SELECT * FROM feedback") or die(mysqli_error($connection));
            echo "<select name='fid'>";
            while ($row = mysqli_fetch_array($sql)) {
                echo "<option value='{$row['feedback_id']}'>{$row['feedback_id']}</option>";
            }
            echo "</select>";
            ?>
            <input type="submit" value="search">
        </form>

        <a href="#" onclick="window.print();"> Print </a>
        <?php

        if (isset($_GET['fid'])) {
            $fid = $_GET['fid'];
            $feedbackq = mysqli_query($connection, "SELECT * FROM feedback WHERE feedback_id = '{$fid}'") or die(mysqli_error($connection));
            $count = mysqli_num_rows($feedbackq);
            echo "<br/>$count Record Found";
            
            if ($count > 0) {
                echo "<table border='1' align='center'>";
                echo "<tr>";
                echo "<th>User ID</th>";
                echo "<th>Worker ID</th>";
                echo "<th>Feedback Rating</th>";
                echo "<th>Feedback Date</th>";
                echo "</tr>";

                while ($row = mysqli_fetch_array($feedbackq)) {
                    echo "<tr>";
                    echo "<td>{$row['user_id']}</td>";
                    echo "<td>{$row['worker_id']}</td>";
                    echo "<td>{$row['feedback_rating']}</td>";
                    echo "<td>{$row['feedback_date']}</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "No records found.";
            }
        }

        ?>
    </body>
</html>
