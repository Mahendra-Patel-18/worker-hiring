<?php
require './atclass.php';
$msg = "";
if ($_POST) {
	$aName = mysqli_real_escape_string($connection, $_POST['txt1']);
	$Apincode = mysqli_real_escape_string($connection, $_POST['txt2']);


	$query = mysqli_query($connection, "INSERT INTO location(area_name,area_pincode) VALUES ('{$aName}','{$Apincode}')") or die(mysqli_error($connection));

	if ($query) {
		$msg = '<div class="alert alert-success" role="alert">
	record added
  </div>';
	}
}
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
	<div class="main-page">
		<div class="forms">
			<h2 class="title1">location</h2>
			<?php
			echo $msg;
			?>

			<div class=" form-grids row form-grids-right">
				<div class="widget-shadow " data-example-id="basic-forms">

					<div class="form-title">
						<h4>location :</h4>
					</div>
					<div class="form-body">
						<form class="form-horizontal" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">area name</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt1" placeholder="enter area name" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">area pincode</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt2" required>
								</div>
							</div>
					</div>
					<div class="col-sm-offset-2"> <button type="submit" class="btn btn-primary">submit</button> </div>

				</div>
			</div>
		</div>
	</div>
</div>

<?php
include "footer.php";
?>