<?php
include "atclass.php";
?>

<html>
    <body>
    <center><img width="200" src="./images/workerhire.jpeg"></center>
        <hr/>
        <center> <h4>Payment Report</h4> </center>
        <?php
        echo "Date: " . date('d-m-y');
        ?>
        <form method="get">

            <?php
            $sql = mysqli_query($connection, "SELECT * FROM payment") or die(mysqli_error($connection));
            echo "<select name='payment_method'>";
            echo "<option value='cash'>Cash</option>";
            echo "<option value='card'>Card</option>";
            echo "<option value='upi'>UPI</option>";
            
            echo "</select>";
            ?>
            <input type="submit" value="search">
        </form>

        <a href="#" onclick="window.print();"> Print </a>
        <?php

        if (isset($_GET['payment_method'])) {
            $payment_method = $_GET['payment_method'];
            $paymentq = mysqli_query($connection, "SELECT * FROM payment WHERE payment_method = '{$payment_method}'") or die(mysqli_error($connection));
            $count = mysqli_num_rows($paymentq);
            echo "<br/>$count Record Found";
            
            if ($count > 0) {
                echo "<table border='1' align='center'>";
                echo "<tr>";
                echo "<th>Payment Id</th>";
                echo "<th>Booking Id</th>";
                echo "<th>Payment Amount</th>";
                echo "<th>Payment Date</th>";

                echo "</tr>";

                while ($row = mysqli_fetch_array($paymentq)) {
                    echo "<tr>";
                    echo "<td>{$row['payment_id']}</td>";
                    echo "<td>{$row['booking_id']}</td>";
                    echo "<td>{$row['payment_amount']}</td>";
                    echo "<td>{$row['payment_date']}</td>";

                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "No records found.";
            }
        }

        ?>
    </body>
</html>
