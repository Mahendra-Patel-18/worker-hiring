<?php
include "atclass.php";
?>

<html>
    <body>
    <center><img width="200" src="./images/workerhire.jpeg"></center>
        <hr/>
        <center> <h4>Category Report</h4> </center>
        <?php
        echo "Date: " . date('d-m-y');
        ?>
        <form method="get">

            <?php
            $sql = mysqli_query($connection, "SELECT * FROM category") or die(mysqli_error($connection));
            echo "<select name='cid'>";
            while ($row = mysqli_fetch_array($sql)) {
                echo "<option value='{$row['category_id']}'>{$row['category_id']}</option>";
            }
            echo "</select>";
            ?>
            <input type="submit" value="search">
        </form>

        <a href="#" onclick="window.print();"> Print </a>
        <?php

        if (isset($_GET['cid'])) {
            $cid = $_GET['cid'];
            $categoryq = mysqli_query($connection, "SELECT * FROM category WHERE category_id = '{$cid}'") or die(mysqli_error($connection));
            $count = mysqli_num_rows($categoryq);
            echo "<br/>$count Record Found";
            
            if ($count > 0) {
                echo "<table border='1' align='center'>";
                echo "<tr>";
                echo "<th>Category Name</th>";
                echo "<th>Category Image</th>";
                echo "</tr>";

                while ($categoryrow = mysqli_fetch_array($categoryq)) {
                    echo "<tr>";
                    echo "<td>{$categoryrow['category_name']}</td>";
                    echo "<td><img width='100px' hight='100px' src='{$categoryrow['category_image']}'/></td>";
                    echo "</tr>";
                }
            
                
                echo "</table>";
            } else {
                echo "No records found.";
            }
        }

        ?>
    </body>
</html>
