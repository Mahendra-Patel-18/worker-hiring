<?php
require './atclass.php';
$msg = "";
if ($_POST) {
    $Wid = mysqli_real_escape_string($connection, $_POST['txt1']);
    $Wname = mysqli_real_escape_string($connection, $_POST['txt2']);
    $Wemail = mysqli_real_escape_string($connection, $_POST['txt3']);
    $gender = mysqli_real_escape_string($connection, $_POST['txt4']);
    $password = mysqli_real_escape_string($connection, $_POST['txt5']);
    $categoryID = mysqli_real_escape_string($connection, $_POST['txt6']);
    $mobileNo = mysqli_real_escape_string($connection, $_POST['txt7']);
    $AreaID = mysqli_real_escape_string($connection, $_POST['txt8']);
    $worker_image = mysqli_real_escape_string($connection, $_FILES['txt9']['name']);

    $uploadDir = "uploads/";
    $uploadFile = $uploadDir . basename($_FILES["txt9"]["name"]);
	$worker_image = $uploadFile;
	
    if (move_uploaded_file($_FILES["txt9"]["tmp_name"], $uploadFile)) {
        $query = mysqli_query($connection, "INSERT INTO worker(
            worker_id,worker_name,worker_email,worker_gender,worker_password,worker_categoryID,worker_mobileNO,worker_areaID,worker_image    
        ) VALUES ('$Wid','$Wname','$Wemail','$gender','$password','$categoryID','$mobileNo','$AreaID','$worker_image')") or die(mysqli_error($connection));
        if ($query) {
            $msg = '<div class="alert alert-success" role="alert">Record added</div>';
        } else {
            $msg = '<div class="alert alert-danger" role="alert">Error adding record</div>';
        }
    } else {
        $msg = '<div class="alert alert-danger" role="alert">Error uploading file</div>';
    }
}
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
    <div class="main-page">
        <div class="forms">
            <h2 class="title1">Worker</h2>
            <?php
            echo $msg;
            ?>

            <div class=" form-grids row form-grids-right">
                <div class="widget-shadow " data-example-id="basic-forms">

                    <div class="form-title">
                        <h4>Worker Details :</h4>
                    </div>
                    <div class="form-body">
                        <form class="form-horizontal" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Worker Id</label>

                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="inputEmail3" name="txt1" placeholder="" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Worker name</label>

                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="inputEmail3" name="txt2" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Email</label>

                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="inputEmail3" name="txt3" placeholder="" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Gender</label>

                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="inputEmail3" name="txt4" placeholder="" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Password</label>

                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="inputEmail3" name="txt5" placeholder="" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Worker categoryID</label>

                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="inputEmail3" name="txt6" placeholder="" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">MobileNo</label>

                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="inputEmail3" name="txt7" placeholder="" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">WorkerAreaID</label>

                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="inputEmail3" name="txt8" placeholder="" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">worker Image</label>


                                <div class="col-sm-9">
                                    <input type="file" class="form-control" id="exampleInputFile" name="txt9" required>
                                </div>
                            </div>
                            <div class="col-sm-offset-2"> <button type="submit" class="btn btn-primary">submit</button> </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include "footer.php";
?>
