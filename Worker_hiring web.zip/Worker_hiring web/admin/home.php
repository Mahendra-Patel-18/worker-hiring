<?php 
session_start();
echo "Hi ".$_SESSION['adminname'] ." ";
if(!isset($_SESSION['adminid']))
{
    echo "<script>alert('Login Required');window.location='login.php';</script>";
}

echo "<a href='change-password.php'>Change Password</a> | ";
echo "<a href='logout.php'>Logout</a>";
?>
