<?php
require './atclass.php';
?>


<?php
include './index.php';
?>

<div id="page-wrapper">
    <div class="main-page">
        <div class="tables">
            <h2 class="title1">Category Tables </h2>
            <div class="panel-body widget-shadow">

                <a href="category.php">
                    <h4>Category Details</h4>
                </a>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Category ID</th>
                            <th>Category Name</th>
                            <th>Category Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (isset($_GET['did'])) {
                            $did = $_GET['did'];

                            $deleteq =  mysqli_query($connection, "DELETE FROM category WHERE category_id ='{$did}'") or die(mysqli_error($connection));
                            if ($deleteq) {
                                echo "<script>alert('Record deleted')</script>";
                            }
                        }
                        $selectq = mysqli_query($connection, "SELECT * FROM category") or die(mysqli_error($connection));
                        $count = mysqli_num_rows($selectq);

                        echo $count . " records found";
                        while ($categoryrow = mysqli_fetch_array($selectq)) {
                            echo "<tr>";
                            echo "<td>{$categoryrow['category_id']}</td>";
                            echo "<td>{$categoryrow['category_name']}</td>";
                            echo "<td><img width='100px' hight='100px' src='{$categoryrow['category_image']}'/></td>";
                            echo "<td><a href='category.php?eid={$categoryrow['category_id']}'> EDIT</a> | <a href='?did={$categoryrow['category_id']}' onclick='return confirm(\"Are you sure you want to delete this category?\");'> DELETE</a></td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

<?php
include "footer.php";
?>