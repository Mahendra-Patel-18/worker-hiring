<?php
session_start();
include "atclass.php";

//Login Check
if (!isset($_SESSION['aid'])) {
    header("location:login.php");
}
if($_POST)
{
    $opass = $_POST['opass'];
    $npass = $_POST['npass'];
    $cpass = $_POST['cpass'];
    $aid = $_SESSION['aid']; 
    $oldpassq  = mysqli_query($connection,"SELECT * FROM admin WHERE admin_id='{$aid}'");
    if (!$oldpassq) {
        die("Query failed: " . mysqli_error($connection));
    }
    $oldpassdb = mysqli_fetch_array($oldpassq);
    if ($oldpassdb) {
        if($oldpassdb['admin_password'] == $opass) {
            if($npass == $cpass) {
                if($opass == $npass) {
                    echo "<script>alert('Old Password and New Password Must be Different')</script>";
                } else {
                    $uq = mysqli_query($connection,"UPDATE admin SET admin_password = '{$npass}' WHERE admin_id='{$aid}'");
                    if (!$uq) {
                        die("Query failed: " . mysqli_error($connection));
                    }
                    echo "<script>alert('Password Changed')</script>";
                }
            } else {
                echo "<script>alert('New and Confirm Password Not Match');</script>";
            }
        } else {
            echo "<script>alert('Old Password Not Match');</script>";
        }
    } else {
        echo "<script>alert('No matching record found for the provided admin ID');</script>";
    }
}
?>

<?php
include "index.php";
?>

<div id="page-wrapper">
    <div class="main-page signup-page">
        <h2 class="title1">Change Password</h2>
        <div class="sign-up-row widget-shadow">
            <h5>Fill the details :</h5>
            <form method="post">
                
                <div class="sign-u">
                    <input type="password" name="opass" placeholder="Enter old Password" required="">
                    <div class="clearfix"> </div>
                </div>

                <div class="sign-u">
                    <input type="password" name="npass" placeholder="Enter New Password" required="">
                    <div class="clearfix"> </div>
                </div>

                <div class="sign-u">
                    <input type="password" name="cpass" placeholder="Confirm New Password" required="">
                    <div class="clearfix"> </div>
                </div>
                
                <div class="sub_home">
                    <input type="submit" value="Submit">
                    <div class="clearfix"> </div>
                </div>
            </form>     
        </div>
    </div>
</div>

<?php
include "footer.php";
?>
