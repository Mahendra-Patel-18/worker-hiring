<?php
include "atclass.php";
?>

<html>
    <body>
    <center><img width="200" src="./images/workerhire.jpeg"></center>
        <hr/>
        <center> <h4>Location Report</h4> </center>
        <?php
        echo "Date: " . date('d-m-y');
        ?>
        <form method="get">

            <?php
            $sql = mysqli_query($connection, "SELECT * FROM location") or die(mysqli_error($connection));
            echo "<select name='Aid'>";
            while ($row = mysqli_fetch_array($sql)) {
                echo "<option value='{$row['area_id']}'>{$row['area_id']}</option>";
            }
            echo "</select>";
            ?>
            <input type="submit" value="search">
        </form>

        <a href="#" onclick="window.print();"> Print </a>
        <?php

        if (isset($_GET['Aid'])) {
            $Aid = $_GET['Aid'];
            $locationq = mysqli_query($connection, "SELECT * FROM location WHERE area_id = '{$Aid}'") or die(mysqli_error($connection));
            $count = mysqli_num_rows($locationq);
            echo "<br/>$count Record Found";
            
            if ($count > 0) {
                echo "<table border='1' align='center'>";
                echo "<tr>";
                echo "<th>Area ID</th>";
                echo "<th>Area name</th>";
                echo "<th>Area Pincode</th>";
                echo "</tr>";

                while ($row = mysqli_fetch_array($locationq)) {
                    echo "<tr>";
                    echo "<td>{$row['area_id']}</td>";
                    echo "<td>{$row['area_name']}</td>";
                    echo "<td>{$row['area_pincode']}</td>";
                    
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "No records found.";
            }
        }

        ?>
    </body>
</html>
