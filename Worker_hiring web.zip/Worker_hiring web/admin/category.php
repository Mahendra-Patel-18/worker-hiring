<?php
require './atclass.php';
$msg = "";
if ($_POST) {
	$cname = mysqli_real_escape_string($connection, $_POST['txt1']);
	$cimage = mysqli_real_escape_string($connection, $_POST['txt2']);

	$uploadDir = "uploads/";
	$uploadFile = $uploadDir . basename($_FILES["txt2"]["name"]);
	$cimage = $uploadFile;

	if (move_uploaded_file($_FILES["txt2"]["tmp_name"], $uploadFile)) {
		$query = mysqli_query($connection, "INSERT INTO category(category_name, category_image) VALUES ('{$cname}', '{$cimage}')") or die(mysqli_error($connection));

		if ($query) {
			$msg = '<div class="alert alert-success" role="alert">Record added</div>';
		} else {
			$msg = '<div class="alert alert-danger" role="alert">Error adding record</div>';
		}
	} else {
		$msg = '<div class="alert alert-danger" role="alert">Error uploading file</div>';
	}
}
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
	<div class="main-page">
		<div class="forms">
			<h2 class="title1">Category Form</h2>
			<?php
			echo $msg;
			?>

			<div class=" form-grids row form-grids-right">
				<div class="widget-shadow " data-example-id="basic-forms">

					<div class="form-title">
						<h4>Category Details :</h4>
					</div>
					<div class="form-body">
						<form class="form-horizontal" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Category Name</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt1" placeholder="Enter Category Name" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Category Image</label>


								<div class="col-sm-9">
									<input type="file" class="form-control" id="exampleInputFile" name="txt2" required>
								</div>
							</div>

					</div>
					<div class="col-sm-offset-2"> <button type="submit" class="btn btn-primary">submit</button> </div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
include "footer.php";
?>