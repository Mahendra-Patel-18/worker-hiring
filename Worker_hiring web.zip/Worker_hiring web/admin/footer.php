<!--footer-->
        <div class="footer">
            <p>&copy; 2024 All Rights Reserved.</p>
        </div>
<!--//footer-->