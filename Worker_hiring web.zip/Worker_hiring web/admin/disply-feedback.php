<?php
require './atclass.php';
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
    <div class="main-page">
        <div class="tables">
            <h2 class="title1">feeback_Table </h2>
            <div class="panel-body widget-shadow">

                <a href="feedback.php">
                    <h4>feeback details Add</h4>
                </a>
                <table class="table">
                    <thead>
                        <tr>

                            <th>feedback ID</th>
                            <th>feedback rating</th>
                            <th>user id</th>
                            <th>worker id</th>
                            <th>feedback date</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (isset($_GET['did'])) {
                            $did = $_GET['did'];

                            $deleteq =  mysqli_query($connection, "delete from feedback where feedback_id ='{$did}'") or die(mysqli_error($connection));
                            if ($deleteq) {
                                echo "<script>alert('record_deleted')</script>";
                            }
                        }
                        $selectq = mysqli_query($connection, "select * from feedback") or die(mysqli_error($connection));
                        $count = mysqli_num_rows($selectq);


                        echo $count . "record_found";
                        while ($feedbackrow = mysqli_fetch_array($selectq)) {
                            echo "<tr>";
                            echo "<td>{$feedbackrow['feedback_id']}</td>";
                            echo "<td>{$feedbackrow['feedback_rating']}</td>";
                            echo "<td>{$feedbackrow['user_id']}</td>";
                            echo "<td>{$feedbackrow['worker_id']}</td>";
                            echo "<td>{$feedbackrow['feedback_date']}</td>";
                            echo "<td><a href='feedback.php?eid={$feedbackrow['feedback_id']}'>EDIT</a> |<a href='disply-feedback.php?did={$feedbackrow['feedback_id']}'> DELETE</a> <td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

<?php
include "footer.php";
?>