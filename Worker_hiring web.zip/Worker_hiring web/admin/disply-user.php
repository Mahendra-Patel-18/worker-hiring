<?php
require './atclass.php';
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
    <div class="main-page">
        <div class="tables">
            <h2 class="title1">user_table </h2>
            <div class="panel-body widget-shadow">

                <a href="user.php">
                    <h4>user detail</h4>
                </a>
                <table class="table">
                    <thead>
                        <tr>

                            <th>user id</th>
                            <th>user name</th>
                            <th>user email</th>
                            <th>user gender</th>
                            <th>user password</th>
                            <th>user address</th>
                            <th>user mobileNo</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (isset($_GET['did'])) {
                            $did = $_GET['did'];

                            $deleteq =  mysqli_query($connection, "delete from user where user_id ='{$did}'") or die(mysqli_error($connection));
                            if ($deleteq) {
                                echo "<script>alert('record_deleted')</script>";
                            }
                        }
                        $selectq = mysqli_query($connection, "select * from user") or die(mysqli_error($connection));
                        $count = mysqli_num_rows($selectq);


                        echo $count . "record_found";
                        while ($userrow = mysqli_fetch_array($selectq)) {
                            echo "<tr>";
                            echo "<td>{$userrow['user_id']}</td>";
                            echo "<td>{$userrow['user_name']}</td>";
                            echo "<td>{$userrow['user_email']}</td>";
                            echo "<td>{$userrow['user_gender']}</td>";
                            echo "<td>{$userrow['user_password']}</td>";
                            echo "<td>{$userrow['user_address']}</td>";
                            echo "<td>{$userrow['user_mobileNo']}</td>";
                            echo "<td><a href='user.php?eid={$userrow['user_id']}'><img src=''>EDIT</a> |<a href='disply-user.php?did={$userrow['user_id']}'><img src=''> DELETE</a> <td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

<?php
include "footer.php";
?>