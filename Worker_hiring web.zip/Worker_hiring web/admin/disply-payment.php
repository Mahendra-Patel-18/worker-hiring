<?php
require './atclass.php';
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
    <div class="main-page">
        <div class="tables">
            <h2 class="title1">payment_table </h2>
            <div class="panel-body widget-shadow">

                <a href="payment.php">
                    <h4>payment detail</h4>
                </a>
                <table class="table">
                    <thead>
                        <tr>

                            <th>payment id</th>
                            <th>payment method</th>
                            <th>payment amount</th>
                            <th>payment date</th>
                            <th>booking id</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (isset($_GET['did'])) {
                            $did = $_GET['did'];

                            $deleteq =  mysqli_query($connection, "delete from payment where payment_id ='{$did}'") or die(mysqli_error($connection));
                            if ($deleteq) {
                                echo "<script>alert('record_deleted')</script>";
                            }
                        }
                        $selectq = mysqli_query($connection, "select * from payment") or die(mysqli_error($connection));
                        $count = mysqli_num_rows($selectq);


                        echo $count . "record_found";
                        while ($paymentrow = mysqli_fetch_array($selectq)) {
                            echo "<tr>";
                            echo "<td>{$paymentrow['payment_id']}</td>";
                            echo "<td>{$paymentrow['payment_method']}</td>";
                            echo "<td>{$paymentrow['payment_amount']}</td>";
                            echo "<td>{$paymentrow['payment_date']}</td>";
                            echo "<td>{$paymentrow['booking_id']}</td>";
                            echo "<td><a href='payment.php?eid={$paymentrow['payment_id']}'>EDIT</a> |<a href='disply-payment.php?did={$paymentrow['payment_id']}'> DELETE</a> <td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

<?php
include "footer.php";
?>