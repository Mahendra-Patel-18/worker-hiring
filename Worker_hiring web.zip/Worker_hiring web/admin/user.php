<?php
require './atclass.php';
$msg = "";
if ($_POST) {
	$Uid = mysqli_real_escape_string($connection, $_POST['txt1']);
	$Uname = mysqli_real_escape_string($connection, $_POST['txt2']);
	$email = mysqli_real_escape_string($connection, $_POST['txt3']);
	$gender = mysqli_real_escape_string($connection, $_POST['txt4']);
	$password = mysqli_real_escape_string($connection, $_POST['txt5']);
	$address = mysqli_real_escape_string($connection, $_POST['txt6']);
	$mobileNo = mysqli_real_escape_string($connection, $_POST['txt7']);

	$query = mysqli_query($connection, "INSERT INTO user(
    user_id,user_name,user_email,user_gender,user_password,user_address,user_mobileNo
) VALUES ('{$Uid}','{$Uname}','{$email}','{$gender}','{$password}','{$address}','{$mobileNo}')") or die(mysqli_error($connection));

	if ($query) {
		$msg = '<div class="alert alert-success" role="alert">
	record added
  </div>';
	}
}
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
	<div class="main-page">
		<div class="forms">
			<h2 class="title1">User</h2>
			<?php
			echo $msg;
			?>

			<div class=" form-grids row form-grids-right">
				<div class="widget-shadow " data-example-id="basic-forms">

					<div class="form-title">
						<h4>User Details :</h4>
					</div>
					<div class="form-body">
						<form class="form-horizontal" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">User Id</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt1" placeholder="" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">User name</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt2" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Email</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt3" placeholder="" required>

								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Gender</label>


								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt4" placeholder="" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Password</label>


								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt5" placeholder="" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Address</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt6" placeholder="" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">MobileNo</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt7" placeholder="" required>
								</div>
							</div>

					</div>
					<div class="col-sm-offset-2"> <button type="submit" class="btn btn-primary">submit</button> </div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
include "footer.php";
?>