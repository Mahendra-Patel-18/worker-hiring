<?php
require './atclass.php';;
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
    <div class="main-page">
        <div class="tables">
            <h2 class="title1">Admin_Tables </h2>
            <div class="panel-body widget-shadow">

                <a href="admin.php">
                    <h4>Admin details Add</h4>
                </a>
                <table class="table">
                    <thead>
                        <tr>

                            <th>admin ID</th>
                            <th>admin name</th>
                            <th>admin email</th>
                            <th>admin password</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (isset($_GET['did'])) {
                            $did = $_GET['did'];

                            $deleteq =  mysqli_query($connection, "delete from admin where admin_id ='{$did}'") or die(mysqli_error($connection));
                            if ($deleteq) {
                                echo "<script>alert('record_deleted')</script>";
                            }
                        }
                        $selectq = mysqli_query($connection, "select * from admin") or die(mysqli_error($connection));
                        $count = mysqli_num_rows($selectq);


                        echo $count . "record_found";
                        while ($adminrow = mysqli_fetch_array($selectq)) {
                            echo "<tr>";
                            echo "<td>{$adminrow['admin_id']}</td>";
                            echo "<td>{$adminrow['admin_name']}</td>";
                            echo "<td>{$adminrow['admin_email']}</td>";
                            echo "<td>{$adminrow['admin_password']}</td>";
                            echo "<td><a href='admin.php?eid={$adminrow['admin_id']}'>EDIT</a> |<a href='disply-admin.php?did={$adminrow['admin_id']}'> DELETE</a> <td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

<?php
include "footer.php";
?>