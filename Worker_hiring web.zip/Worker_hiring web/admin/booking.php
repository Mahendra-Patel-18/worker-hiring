<?php
require './atclass.php';
$msg = "";
if ($_POST) {
	$Bid = mysqli_real_escape_string($connection, $_POST['txt1']);
	$Bdate = mysqli_real_escape_string($connection, $_POST['txt2']);
	$Uid = mysqli_real_escape_string($connection, $_POST['txt3']);
	$Wname = mysqli_real_escape_string($connection, $_POST['txt4']);
	$Wtype = mysqli_real_escape_string($connection, $_POST['txt5']);
	$Baddress = mysqli_real_escape_string($connection, $_POST['txt6']);
	$status = mysqli_real_escape_string($connection, $_POST['txt7']);
	$amount = mysqli_real_escape_string($connection, $_POST['txt8']);


	$query = mysqli_query($connection, "INSERT INTO booking(booking_id,booking_date,user_id,worker_name,worker_type,booking_address,booking_status,booking_amount	
) VALUES ('{$Bid}','{$Bdate}','{$Uid}','{$Wname}','{$Wtype}','{$Baddress}','{$status}','{$amount}')") or die(mysqli_error($connection));

	if ($query) {
		$msg = '<div class="alert alert-success" role="alert">
	record added
  </div>';
	}
}
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
	<div class="main-page">
		<div class="forms">
			<h2 class="title1">Booking</h2>
			<?php
			echo $msg;
			?>

			<div class=" form-grids row form-grids-right">
				<div class="widget-shadow " data-example-id="basic-forms">

					<div class="form-title">
						<h4>Booking Details :</h4>
					</div>
					<div class="form-body">
						<form class="form-horizontal" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">booking Id</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt1" placeholder="" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Booking Date</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt2" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">User ID</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt3" placeholder="" required>

								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Worker Name</label>


								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt4" placeholder="" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Worker Type</label>


								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt5" placeholder="" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Booking Address</label>


								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt6" placeholder="" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">booking status</label>


								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt7" placeholder="" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Booking Amount</label>


								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt8" placeholder="" required>
								</div>
							</div>

					</div>
					<div class="col-sm-offset-2"> <button type="submit" class="btn btn-primary">submit</button> </div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
include "footer.php";
?>