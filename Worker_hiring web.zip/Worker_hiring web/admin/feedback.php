<?php
require './atclass.php';
$msg = "";
if ($_POST) {
	$Fid = mysqli_real_escape_string($connection, $_POST['txt1']);
	$Frating = mysqli_real_escape_string($connection, $_POST['txt2']);
	$Uid = mysqli_real_escape_string($connection, $_POST['txt3']);
	$Wid = mysqli_real_escape_string($connection, $_POST['txt4']);
	$Fdate = mysqli_real_escape_string($connection, $_POST['txt5']);


	$query = mysqli_query($connection, "INSERT INTO feedback(feedback_id,feedback_rating,user_id,worker_id,feedback_date) VALUES ('{$Fid}','{$Frating}','{$Uid}','{$Wid}','{$Fdate}')") or die(mysqli_error($connection));

	if ($query) {
		$msg = '<div class="alert alert-success" role="alert">
	record added
  </div>';
	}
}
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
	<div class="main-page">
		<div class="forms">
			<h2 class="title1">category form</h2>
			<?php
			echo $msg;
			?>

			<div class=" form-grids row form-grids-right">
				<div class="widget-shadow " data-example-id="basic-forms">

					<div class="form-title">
						<h4>category details :</h4>
					</div>
					<div class="form-body">
						<form class="form-horizontal" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">feedback id</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt1" placeholder="" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">feedback rating</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt2" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">user id</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt3" placeholder="" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">worker id</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt4" placeholder="" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">feedback date</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt5" placeholder="" required>
								</div>
							</div>
					</div>
					<div class="col-sm-offset-2"> <button type="submit" class="btn btn-primary">submit</button> </div>

				</div>
			</div>
		</div>
	</div>
</div>

<?php
include "footer.php";
?>