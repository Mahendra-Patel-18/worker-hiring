<?php
include "atclass.php";
?>

<html>
    <body>
    <center><img width="200" src="./images/workerhire.jpeg"></center>
        <hr/>
        <center> <h4>Booking Report</h4> </center>
        <?php
        echo "Date: " . date('d-m-y');
        ?>
        <form method="get">
            <label for="start_date">Start Date:</label>
            <input type="date" name="start_date" required>

            <label for="end_date">End Date:</label>
            <input type="date" name="end_date" required>

            <input type="submit" value="Search">
        </form>

        <a href="#" onclick="window.print();"> Print </a>
        <?php

        if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
            $start_date = $_GET['start_date'];
            $end_date = $_GET['end_date'];

            $bookingq = mysqli_query($connection, "SELECT * FROM booking WHERE booking_date BETWEEN '{$start_date}' AND '{$end_date}'") or die(mysqli_error($connection));
            $count = mysqli_num_rows($bookingq);
            echo "<br/>$count Record(s) Found";

            if ($count > 0) {
                echo "<table border='1' align='center'>";
                echo "<tr>";
                echo "<th>Booking ID</th>";
                echo "<th>User ID</th>";
                echo "<th>Worker Name</th>";
                echo "<th>Worker Type</th>";
                echo "<th>Booking Status</th>";
                echo "<th>Booking Amount</th>";
                echo "<th>Booking Date</th>";

                echo "</tr>";

                while ($row = mysqli_fetch_array($bookingq)) {
                    echo "<tr>";
                    echo "<td>{$row['booking_id']}</td>";
                    echo "<td>{$row['user_id']}</td>";
                    echo "<td>{$row['worker_name']}</td>";
                    echo "<td>{$row['worker_type']}</td>";
                    echo "<td>{$row['booking_status']}</td>";
                    echo "<td>{$row['booking_amount']}</td>";
                    echo "<td>{$row['booking_date']}</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "No records found.";
            }
        }

        ?>
    </body>
</html>