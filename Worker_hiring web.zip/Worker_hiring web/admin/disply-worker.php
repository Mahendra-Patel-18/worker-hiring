<?php
require './atclass.php';
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
    <div class="main-page">
        <div class="tables">
            <h2 class="title1">worker_table </h2>
            <div class="panel-body widget-shadow">

                <a href="admin.php">
                    <h4>worker details</h4>
                </a>
                <table class="table">
                    <thead>
                        <tr>

                            <th>worker ID</th>
                            <th>worker name</th>
                            <th>worker email</th>
                            <th>worker gender</th>
                            <th>worker password</th>
                            <th>worker categoryID</th>
                            <th>worker mobileNO</th>
                            <th>worker areaID</th>
                            <th>worker image</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (isset($_GET['did'])) {
                            $did = $_GET['did'];

                            $deleteq =  mysqli_query($connection, "delete from worker where worker_id ='{$did}'") or die(mysqli_error($connection));
                            if ($deleteq) {
                                echo "<script>alert('record_deleted')</script>";
                            }
                        }
                        $selectq = mysqli_query($connection, "select * from worker") or die(mysqli_error($connection));
                        $count = mysqli_num_rows($selectq);


                        echo $count . "record_found";
                        while ($workerrow = mysqli_fetch_array($selectq)) {
                            echo "<tr>";
                            echo "<td>{$workerrow['worker_id']}</td>";
                            echo "<td>{$workerrow['worker_name']}</td>";
                            echo "<td>{$workerrow['worker_email']}</td>";
                            echo "<td>{$workerrow['worker_gender']}</td>";
                            echo "<td>{$workerrow['worker_password']}</td>";
                            echo "<td>{$workerrow['worker_categoryID']}</td>";
                            echo "<td>{$workerrow['worker_mobileNO']}</td>";
                            echo "<td>{$workerrow['worker_areaID']}</td>";
                            echo "<td><img width='100px' height='100px' src='{$workerrow['worker_image']}'/></td>";
                            echo "<td><a href='worker.php?eid={$workerrow['worker_id']}'>EDIT</a> |<a href='disply-worker.php?did={$workerrow['worker_id']}'> DELETE</a> <td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

<?php
include "footer.php";
?>