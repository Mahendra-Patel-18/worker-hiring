<?php
require './atclass.php';
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
    <div class="main-page">
        <div class="tables">
            <h2 class="title1">booking_Tables </h2>
            <div class="panel-body widget-shadow">

                <a href="booking.php">
                    <h4>booking details</h4>
                </a>
                <table class="table">
                    <thead>
                        <tr>

                            <th>booking id</th>
                            <th>booking date</th>
                            <th>user id</th>
                            <th>worker name</th>
                            <th>worker type</th>
                            <th>booking address</th>
                            <th>booking status</th>
                            <th>booking amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (isset($_GET['did'])) {
                            $did = $_GET['did'];

                            $deleteq =  mysqli_query($connection, "delete from booking where booking_id ='{$did}'") or die(mysqli_error($connection));
                            if ($deleteq) {
                                echo "<script>alert('record_deleted')</script>";
                            }
                        }
                        $selectq = mysqli_query($connection, "select * from booking") or die(mysqli_error($connection));
                        $count = mysqli_num_rows($selectq);


                        echo $count . "record_found";
                        while ($bookingrow = mysqli_fetch_array($selectq)) {
                            echo "<tr>";
                            echo "<td>{$bookingrow['booking_id']}</td>";
                            echo "<td>{$bookingrow['booking_date']}</td>";
                            echo "<td>{$bookingrow['user_id']}</td>";
                            echo "<td>{$bookingrow['worker_name']}</td>";
                            echo "<td>{$bookingrow['worker_type']}</td>";
                            echo "<td>{$bookingrow['booking_address']}</td>";
                            echo "<td>{$bookingrow['booking_status']}</td>";
                            echo "<td>{$bookingrow['booking_amount']}</td>";
                            echo "<td><a href='booking.php?eid={$bookingrow['booking_id']}'>EDIT</a> |<a href='disply-booking.php?did={$bookingrow['booking_id']}'> DELETE</a> <td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

<?php
include "footer.php";
?>