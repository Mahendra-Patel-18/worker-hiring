<?php
require './atclass.php';
$msg = "";
if ($_POST) {
	$Aid = mysqli_real_escape_string($connection, $_POST['txt1']);
	$Aname = mysqli_real_escape_string($connection, $_POST['txt2']);
	$Aemail = mysqli_real_escape_string($connection, $_POST['txt3']);
	$Apassword = mysqli_real_escape_string($connection, $_POST['txt4']);

	$query = mysqli_query($connection, "INSERT INTO admin(admin_id,admin_name,admin_email,admin_password) VALUES ('{$Aid}','{$Aname}','{$Aemail}','{$Apassword}')") or die(mysqli_error($connection));

	if ($query) {
		$msg = '<div class="alert alert-success" role="alert">
	record added
  </div>';
	}
}
?>

<?php
include './index.php';
?>

<div id="page-wrapper">
	<div class="main-page">
		<div class="forms">
			<h2 class="title1">Admin form</h2>
			<?php
			echo $msg;
			?>

			<div class=" form-grids row form-grids-right">
				<div class="widget-shadow " data-example-id="basic-forms">


					<div class="form-title">
						<h4>admin details :</h4>
					</div>
					<div class="form-body">
						<form class="form-horizontal" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Admin id</label>


								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt1" placeholder="" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Admin name</label>


								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt2" required>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">Admin Email</label>


								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt3" placeholder="" required>

								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail3" class="col-sm-2 control-label">password</label>

								<div class="col-sm-9">
									<input type="text" class="form-control" id="inputEmail3" name="txt4" placeholder="" required>
								</div>
							</div>
					</div>
					<div class="col-sm-offset-2"> <button type="submit" class="btn btn-primary">submit</button> </div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
include "footer.php";
?>